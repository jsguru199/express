global.API_URL = 'http://localhost:3000';
